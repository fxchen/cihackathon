
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.5.2'
version = '1.5.2'
full_version = '1.5.2'
git_revision = '01d8bfb6f239df4ce70c799b9b485b53733c9911'
release = True

if not release:
    version = full_version
